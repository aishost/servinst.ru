<?php if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php $APPLICATION->ShowTitle(); ?></title>
		<?php $APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH . '/css/style.css'); ?>
		<?php $APPLICATION->ShowHead(); ?>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
	</head>
<body>
<div id="panel">
	<?php $APPLICATION->ShowPanel();?>
</div>
<section class="block1">
    <div class="block1__zag"><h1>Аренда</h1></div>
    <div class="block1__poazag"></div>
    <div class="block1__video">
             <div class="block1__video_box">
                   <iframe src="https://www.youtube.com/embed/xxxxxxxxxxx?controls=0&showinfo=0&rel=0&autoplay=1&loop=1&mute=1&playlist=xxxxxxxxxxx" allowfullscreen>
                      </div>
    </div>
</section>
<div id="app">
      <!-- показываем, что надо вывести что-то на экран -->
      {{ message }}
    </div>
<script>

	 // создаём новое приложение для первого блока
	 var app = new Vue({
        // привязываем его через название
        el: "#app",
        // пишем сообщение, которое нужно вывести
        data: {
          message: "Привет, это журнал «Код»!"
        }
      });

</script>