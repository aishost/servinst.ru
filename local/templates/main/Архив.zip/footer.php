<?php if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();?>

<!-- main scripts -->
			<!-- Загрузим наш VUE-компонент. -->


    <!-- Load our React component. -->

<script src="<?php echo SITE_TEMPLATE_PATH?>/js/app.js"></script>
	</body>
</html>